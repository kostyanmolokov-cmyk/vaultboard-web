// Service worker: открытие сайта + автозаполнение, автоблокировка, фоновая синхронизация.
import { getSessionKey, clearSessionKey, loadEnvelope, readData, getPrefs, getSyncState } from './lib/store.js';
import { syncNow } from './lib/sync.js';
import { normalizeUrl, hostOf, sameSite } from './lib/domain.js';
import { fillInPage } from './lib/fill.js';

const APP_URL = chrome.runtime.getURL('app.html');
const PENDING_TTL = 2 * 60 * 1000;

// ───────── окно приложения ─────────
async function openApp() {
  const tabs = await chrome.tabs.query({ url: APP_URL });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: APP_URL });
  }
}
chrome.action.onClicked.addListener(openApp);

// ───────── автоблокировка ─────────
async function scheduleAutolock() {
  const { autolockMin } = await getPrefs();
  await chrome.alarms.clear('autolock');
  if (autolockMin > 0) chrome.alarms.create('autolock', { delayInMinutes: Math.max(1, autolockMin) });
}

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === 'autolock') await clearSessionKey();
  if (a.name === 'sync') syncNow().catch(() => {});
});
chrome.alarms.create('sync', { periodInMinutes: 3 });

// ───────── ожидающие подстановки ─────────
async function getPending() { return (await chrome.storage.session.get('pending')).pending || {}; }
async function setPending(p) { await chrome.storage.session.set({ pending: p }); }

async function launch(itemId) {
  const key = await getSessionKey();
  if (!key) throw new Error('Хранилище заблокировано');
  const data = await readData(key, await loadEnvelope());
  const item = data.items.find((i) => i.id === itemId && !i.deleted);
  if (!item) throw new Error('Запись не найдена');
  const url = normalizeUrl(item.url);
  if (!url) throw new Error('У записи нет адреса');
  const tab = await chrome.tabs.create({ url });
  const pending = await getPending();
  pending[tab.id] = { itemId, host: hostOf(url), until: Date.now() + PENDING_TTL, userDone: false };
  await setPending(pending);
  await scheduleAutolock();
  // если страница успела загрузиться (кэш) — не ждём события
  const fresh = await chrome.tabs.get(tab.id).catch(() => null);
  if (fresh && fresh.status === 'complete' && fresh.url && fresh.url !== 'about:blank') doFill(tab.id, fresh.url);
  return true;
}

async function doFill(tabId, tabUrl) {
  const pending = await getPending();
  const p = pending[tabId];
  if (!p) return;
  if (Date.now() > p.until) { delete pending[tabId]; return setPending(pending); }
  // подставляем только на том же сайте, что и в записи
  if (!sameSite(hostOf(tabUrl), p.host)) return;
  const key = await getSessionKey();
  if (!key) return;
  try {
    const data = await readData(key, await loadEnvelope());
    const item = data.items.find((i) => i.id === p.itemId && !i.deleted);
    if (!item) { delete pending[tabId]; return setPending(pending); }
    const [res] = await chrome.scripting.executeScript({
      target: { tabId }, // только верхний фрейм: данные не уходят в сторонние iframe
      func: fillInPage,
      args: [{ username: item.username, password: item.password, autoSubmit: !!item.autoSubmit, skipUser: p.userDone, timeoutMs: 15000 }],
    });
    const r = res?.result || {};
    const cur = await getPending();
    if (r.passDone) delete cur[tabId];
    else if (cur[tabId]) cur[tabId].userDone = !!r.userDone;
    await setPending(cur);
  } catch (e) {
    // нет разрешения на сайт или вкладка закрыта — больше не пытаемся
    const cur = await getPending();
    delete cur[tabId];
    await setPending(cur);
  }
}

// ───────── автозаполнение при открытии любого сайта ─────────
const autoBusy = new Set();
async function autoFill(tabId, tabUrl) {
  let u; try { u = new URL(tabUrl); } catch { return; }
  if (!/^https?:$/.test(u.protocol)) return;
  const prefs = await getPrefs();
  if (prefs.autofill === false) return;
  const key = await getSessionKey();
  if (!key) return;
  const tag = tabId + '|' + u.origin + u.pathname;
  if (autoBusy.has(tag)) return;
  autoBusy.add(tag);
  try {
    if (!(await chrome.permissions.contains({ origins: [u.origin + '/*'] }))) return;
    const data = await readData(key, await loadEnvelope());
    const host = u.hostname.toLowerCase();
    // чем точнее запись совпадает со страницей (хост, затем путь), тем она выше
    const score = (i) => {
      const iu = (() => { try { return new URL(normalizeUrl(i.url)); } catch { return null; } })();
      return (hostOf(i.url) === host ? 2 : 0) + (iu && iu.pathname.replace(/\/$/, '') === u.pathname.replace(/\/$/, '') ? 1 : 0);
    };
    const cands = data.items
      .filter((i) => i.type === 'login' && !i.deleted && i.password && i.url && sameSite(hostOf(i.url), host))
      // с https на http не опускаемся: пароль не должен уйти по незащищённому каналу
      .filter((i) => u.protocol === 'https:' || parseUrlProto(i.url) === 'http:')
      .sort((a, b) => score(b) - score(a) || (b.updatedAt || 0) - (a.updatedAt || 0));
    const item = cands[0];
    if (!item) return;
    await chrome.scripting.executeScript({
      target: { tabId },
      func: fillInPage,
      args: [{ username: item.username, password: item.password, autoSubmit: !!item.autoSubmit, skipUser: false, timeoutMs: 8000, auto: true }],
    });
  } catch { /* вкладка закрыта или нет доступа */ } finally {
    setTimeout(() => autoBusy.delete(tag), 10000);
  }
}
function parseUrlProto(x) { try { return new URL(normalizeUrl(x)).protocol; } catch { return ''; } }

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete' || !tab.url) return;
  const pending = await getPending();
  if (pending[tabId]) doFill(tabId, tab.url); else autoFill(tabId, tab.url);
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const p = await getPending();
  if (p[tabId]) { delete p[tabId]; await setPending(p); }
});

// ───────── сообщения от интерфейса ─────────
let syncTimer = null;
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return;
  (async () => {
    switch (msg?.cmd) {
      case 'launch': await launch(msg.itemId); return { ok: true };
      case 'touch': await scheduleAutolock(); return { ok: true };
      case 'lock': await clearSessionKey(); return { ok: true };
      case 'syncSoon': {
        clearTimeout(syncTimer);
        syncTimer = setTimeout(() => syncNow().catch(() => {}), 2500);
        return { ok: true };
      }
      case 'syncNow': return { ok: true, result: await syncNow() };
      default: return { ok: false, error: 'unknown' };
    }
  })().then(sendResponse, (e) => sendResponse({ ok: false, error: e.message, code: e.code }));
  return true;
});

chrome.runtime.onInstalled.addListener(async (d) => {
  if (d.reason === 'install') openApp();
});
